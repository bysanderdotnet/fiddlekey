# Bourdon 🎻

**A real-time jam session companion for beginner folk violin players.**

Bourdon listens to the music being played around you and instantly tells you:
- what **key and mode** the tune is in
- which **notes are safe to play**
- where to **put your fingers** on the violin

No sheet music required. No internet required. Just open it on your phone and start playing.

---

## The Problem

Folk jam sessions are intimidating for beginners. There is no conductor, no sheet music handed out, and tunes start without warning. The hardest part is not playing the notes — it is knowing *which* notes are safe, and in *what key* the tune is running. Once you have that, your ear can do the rest.

Bourdon solves exactly that problem.

---

## What It Does

### Core features (v1)
| Feature | Description |
|---|---|
| 🎵 **Key detection** | Detects the tonic and mode (D Dorian, G Mixolydian, A Major, etc.) from live microphone audio within 1–3 seconds |
| 🟢 **Safe notes** | Shows the 5 pentatonic tones and the full 7-note scale for the detected key — the notes you can play without clashing |
| 🖐️ **Finger placement** | SVG violin fingerboard showing which string and finger to use for each safe note, in first position |
| 📱 **Works offline** | Fully client-side PWA — no server, no login, no internet needed at the session |

### Bonus features (v2, later)
- Tune name identification (matching against a folk tune database)
- Link to sheet music / ABC notation on thesession.org
- Transposition — show the same scale in a different position

---

## Who It Is For

A beginner folk violin (or viola/mandolin) player who:
- Knows basic first-position fingering
- Plays in sessions but struggles to identify keys by ear
- Wants to join in without having to memorise every tune first

---

## Getting Started (development)

```bash
git clone https://github.com/bysanderdotnet/bourdon
cd bourdon
npm install
npm run dev
npm run test     # run unit tests
```

Open on your phone at the local network address Vite prints. Grant microphone permission. Play or hum a tune.

```bash
npm run build    # production build
npm run preview  # test the PWA shell locally
```

---

## Infrastructure Setup

### GitHub Secrets

Before the sync workflow can run, set the following secrets in the repo under **Settings → Secrets and variables → Actions**:

| Secret | Description |
|---|---|
| `R2_ACCESS_KEY_ID` | R2 API token access key ID — generated under **R2 → Manage R2 API Tokens** |
| `R2_SECRET_ACCESS_KEY` | R2 API token secret access key — generated at the same time as the above |

### One-time Cloudflare Dashboard Setup

Complete these steps once before the site can load assets from R2:

1. **Create the R2 bucket** named `r2-bourdon` under **R2 → Overview → Create bucket**.
2. **Connect a custom domain** to the bucket (`r2-bourdon.bysander.net`) under **R2 → r2-bourdon → Settings → Public Access → Custom Domains**. This routes traffic through Cloudflare's proxy and enables caching.
3. **Create a Cache Everything rule** in the `bysander.net` zone: **Caching → Cache Rules → Create rule**. Match hostname `r2-bourdon.bysander.net`, set Cache eligibility to "Eligible for cache", set Edge Cache TTL to "Override origin: 1 month".
4. **Enable Smart Tiered Cache** in the `bysander.net` zone: **Caching → Configuration → Tiered Cache → Smart Tiered Cache topology**.
5. **Set a CORS policy** on the bucket allowing `https://bourdon.bysander.net` so the browser can load models cross-origin.

