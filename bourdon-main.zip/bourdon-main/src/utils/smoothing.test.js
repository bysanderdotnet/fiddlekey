import { describe, it, expect } from 'vitest';
import { KeySmoother } from './smoothing';
import { MODES } from './notes.js';

describe('KeySmoother', () => {
  it('should return null for no input', () => {
    const smoother = new KeySmoother();
    expect(smoother.add(null)).toBeNull();
  });

  it('should return the majority estimate', () => {
    const smoother = new KeySmoother(3);

    // First estimate
    expect(smoother.add({ tonic: 2, mode: MODES.IONIAN })).toEqual({ tonic: 2, mode: MODES.IONIAN });

    // Second estimate (different)
    // Majority of [{2, ionian}, {7, ionian}] -> latest is {7, ionian} if counts are tied in my implementation
    expect(smoother.add({ tonic: 7, mode: MODES.IONIAN })).toEqual({ tonic: 7, mode: MODES.IONIAN });

    // Third estimate (back to D Ionian)
    // Majority of [{2, ionian}, {7, ionian}, {2, ionian}] -> {2, ionian}
    expect(smoother.add({ tonic: 2, mode: MODES.IONIAN })).toEqual({ tonic: 2, mode: MODES.IONIAN });
  });

  it('should respect window size', () => {
    const smoother = new KeySmoother(2);

    smoother.add({ tonic: 2, mode: MODES.IONIAN });
    smoother.add({ tonic: 7, mode: MODES.IONIAN });
    // Window is now [{2, ionian}, {7, ionian}]

    // New estimate pushes out the first one
    // Window becomes [{7, ionian}, {9, ionian}]
    expect(smoother.add({ tonic: 9, mode: MODES.IONIAN })).toEqual({ tonic: 9, mode: MODES.IONIAN });

    // Verify {2, major} is gone
    const majority = smoother.getMajority();
    expect(majority.tonic).not.toBe(2);
  });
});
