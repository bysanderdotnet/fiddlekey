export const TONICS = {
  C: 'C',
  C_SHARP: 'C#',
  D: 'D',
  D_SHARP: 'D#',
  E: 'E',
  F: 'F',
  F_SHARP: 'F#',
  G: 'G',
  G_SHARP: 'G#',
  A: 'A',
  A_SHARP: 'A#',
  B: 'B'
};

export const MODES = {
  IONIAN: 'ionian',
  DORIAN: 'dorian',
  PHRYGIAN: 'phrygian',
  LYDIAN: 'lydian',
  MIXOLYDIAN: 'mixolydian',
  AEOLIAN: 'aeolian',
  LOCRIAN: 'locrian'
};

export const NOTE_NAMES = [
  TONICS.C, TONICS.C_SHARP, TONICS.D, TONICS.D_SHARP, TONICS.E, TONICS.F,
  TONICS.F_SHARP, TONICS.G, TONICS.G_SHARP, TONICS.A, TONICS.A_SHARP, TONICS.B
];

export const MODE_MAPPING = {
  [MODES.IONIAN]: 'Major (Ionian)',
  [MODES.LYDIAN]: 'Major (Lydian)',
  [MODES.MIXOLYDIAN]: 'Major (Mixolydian)',
  [MODES.AEOLIAN]: 'Minor (Aeolian)',
  [MODES.DORIAN]: 'Minor (Dorian)',
  [MODES.PHRYGIAN]: 'Minor (Phrygian)',
  [MODES.LOCRIAN]: 'Diminished (Locrian)'
};

/**
 * Returns a harmonized mode name for display.
 * @param {string} mode
 * @returns {string}
 */
export function getFormattedMode(mode) {
  if (!mode) return '';
  const m = mode.toLowerCase();
  return MODE_MAPPING[m] || mode;
}
