// @vitest-environment jsdom
import { describe, it, expect, beforeEach, vi, afterEach } from 'vitest';
import { updateNotesDisplay } from './notes-display.js';
import * as scaleHelper from '../theory/scale-helper.js';
import { TONICS, MODES } from '../utils/notes.js';

describe('updateNotesDisplay', () => {
  let container;
  let consoleErrorSpy;

  beforeEach(() => {
    document.body.innerHTML = '<div id="notes-display"></div>';
    container = document.getElementById('notes-display');
    consoleErrorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('clears container and sets opacity 0 on low confidence', () => {
    updateNotesDisplay({ confidence: 0.05 });
    expect(container.innerHTML).toBe('');
    expect(container.style.opacity).toBe('0');
  });

  it('clears container and sets opacity 0 on missing detection', () => {
    updateNotesDisplay(null);
    expect(container.innerHTML).toBe('');
    expect(container.style.opacity).toBe('0');
  });

  it('returns early if container does not exist', () => {
    document.body.innerHTML = '';
    expect(() => updateNotesDisplay({ confidence: 0.9 })).not.toThrow();
  });

  it('renders correctly for a ionian key with high confidence', () => {
    updateNotesDisplay({ tonic: TONICS.C, mode: MODES.IONIAN, confidence: 0.8 });

    expect(container.style.opacity).toBe('1');

    const pentaRow = container.querySelector('.pentatonic-row');
    expect(pentaRow).not.toBeNull();

    const pentaChips = pentaRow.querySelectorAll('.note-chip.pentatonic');
    expect(pentaChips.length).toBe(5); // C Major pentatonic: C, D, E, G, A

    const tonicChip = pentaRow.querySelector('.note-chip.tonic');
    expect(tonicChip).not.toBeNull();
    expect(tonicChip.textContent).toBe('C');

    const scaleRow = container.querySelector('.scale-row');
    expect(scaleRow).not.toBeNull();

    const scaleChips = scaleRow.querySelectorAll('.note-chip.scale');
    expect(scaleChips.length).toBe(2); // F, B
  });

  it('renders correctly for a aeolian key with high confidence', () => {
    updateNotesDisplay({ tonic: TONICS.A, mode: MODES.AEOLIAN, confidence: 0.9 });

    expect(container.style.opacity).toBe('1');

    const pentaRow = container.querySelector('.pentatonic-row');
    expect(pentaRow).not.toBeNull();

    const pentaChips = pentaRow.querySelectorAll('.note-chip.pentatonic');
    expect(pentaChips.length).toBe(5); // A Minor pentatonic: A, C, D, E, G

    const tonicChip = pentaRow.querySelector('.note-chip.tonic');
    expect(tonicChip).not.toBeNull();
    expect(tonicChip.textContent).toBe('A');

    const scaleRow = container.querySelector('.scale-row');
    expect(scaleRow).not.toBeNull();

    const scaleChips = scaleRow.querySelectorAll('.note-chip.scale');
    expect(scaleChips.length).toBe(2); // B, F
  });

  it('handles tonic as a number', () => {
    // 0 is C in NOTE_NAMES
    updateNotesDisplay({ tonic: 0, mode: MODES.IONIAN, confidence: 0.8 });

    const pentaRow = container.querySelector('.pentatonic-row');
    const tonicChip = pentaRow.querySelector('.note-chip.tonic');
    expect(tonicChip.textContent).toBe('C');
  });

  it('catches and logs errors during scale generation', () => {
    // Mock getPentatonicNotes to throw an error
    vi.spyOn(scaleHelper, 'getPentatonicNotes').mockImplementation(() => {
      throw new Error('Test error');
    });

    updateNotesDisplay({ tonic: TONICS.C, mode: MODES.IONIAN, confidence: 0.8 });

    expect(consoleErrorSpy).toHaveBeenCalled();
    expect(consoleErrorSpy.mock.calls[0][0]).toBe('Error updating notes display:');
  });
});
