import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { startAudio, stopAudio } from './capture.js';

describe('Audio Capture', () => {
  let mockTrack;
  let mockStream;
  let mockAudioContextInstance;

  beforeEach(() => {
    // Reset vi.fn() call counts between tests
    vi.clearAllMocks();

    mockTrack = { stop: vi.fn() };
    mockStream = { getTracks: vi.fn(() => [mockTrack]) };

    vi.stubGlobal('navigator', {
      mediaDevices: {
        getUserMedia: vi.fn().mockResolvedValue(mockStream)
      }
    });

    mockAudioContextInstance = {
      sampleRate: 44100,
      audioWorklet: {
        addModule: vi.fn().mockResolvedValue()
      },
      createMediaStreamSource: vi.fn().mockReturnValue({
        connect: vi.fn(),
        disconnect: vi.fn()
      }),
      close: vi.fn().mockResolvedValue()
    };

    // Fix: AudioContext is called with new, so mock must be a class/constructor function
    class MockAudioContext {
      constructor() {
        return mockAudioContextInstance;
      }
    }
    vi.stubGlobal('window', {
      AudioContext: MockAudioContext
    });

    // Fix: Worker and AudioWorkletNode are called with new
    class MockWorker {
      constructor() {
        this.postMessage = vi.fn();
        this.terminate = vi.fn();
      }
    }
    vi.stubGlobal('Worker', MockWorker);

    class MockAudioWorkletNode {
      constructor() {
        this.port = { onmessage: null };
        this.disconnect = vi.fn();
      }
    }
    vi.stubGlobal('AudioWorkletNode', MockAudioWorkletNode);
  });

  afterEach(async () => {
    await stopAudio();
    vi.unstubAllGlobals();
  });

  describe('startAudio', () => {
    it('should initialize audio correctly and return correct objects', async () => {
      const result = await startAudio();

      expect(result).toBeDefined();
      expect(result.audioContext).toBe(mockAudioContextInstance);
      expect(result.stream).toBe(mockStream);
      expect(result.worker).toBeDefined();
      expect(result.bourdonNode).toBeDefined();

      expect(navigator.mediaDevices.getUserMedia).toHaveBeenCalledWith({
        audio: {
          echoCancellation: false,
          noiseSuppression: false,
          autoGainControl: false
        }
      });
      expect(mockAudioContextInstance.audioWorklet.addModule).toHaveBeenCalled();
    });

    it('should throw an error if getUserMedia fails', async () => {
      const mockError = new Error('Microphone access denied');
      navigator.mediaDevices.getUserMedia.mockRejectedValueOnce(mockError);

      await expect(startAudio()).rejects.toThrow('Microphone access denied');
    });
  });

  describe('stopAudio', () => {
    it('should correctly disconnect nodes and stop stream tracks', async () => {
      // First, initialize so variables are populated
      const result = await startAudio();
      const mockSource = mockAudioContextInstance.createMediaStreamSource.mock.results[0].value;
      const mockBourdonNode = result.bourdonNode;
      const mockWorker = result.worker;

      // Note: we can spy on the methods of mockBourdonNode and mockWorker
      // since they were instantiated via new.
      const bourdonNodeSpy = vi.spyOn(mockBourdonNode, 'disconnect');
      const workerSpy = vi.spyOn(mockWorker, 'terminate');

      // Now, call stopAudio
      await stopAudio();

      expect(mockSource.disconnect).toHaveBeenCalled();
      expect(bourdonNodeSpy).toHaveBeenCalled();
      expect(mockStream.getTracks).toHaveBeenCalled();
      expect(mockTrack.stop).toHaveBeenCalled();
      expect(mockAudioContextInstance.close).toHaveBeenCalled();
      expect(workerSpy).toHaveBeenCalled();
    });

    it('should gracefully handle if variables are already null (never initialized)', async () => {
      // Ensure everything is null
      await stopAudio();

      // Calling it again should not throw errors
      await expect(stopAudio()).resolves.toBeUndefined();
    });
  });
});
