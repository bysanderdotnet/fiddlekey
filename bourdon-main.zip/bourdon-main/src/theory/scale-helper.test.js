import { describe, it, expect } from "vitest";
import { getScaleNotes, getPentatonicNotes, getNoteOctaves } from "./scale-helper";
import { TONICS, MODES } from "../utils/notes.js";

describe("scale-helper", () => {
  describe("getScaleNotes", () => {
    it("should return correct notes for D Dorian", () => {
      const notes = getScaleNotes(TONICS.D, MODES.DORIAN);
      expect(notes).toEqual(["D", "E", "F", "G", "A", "B", "C"]);
    });

    it("should return correct notes for G Ionian", () => {
      const notes = getScaleNotes(TONICS.G, MODES.IONIAN);
      expect(notes).toEqual(["G", "A", "B", "C", "D", "E", "F#"]);
    });
  });

  describe("getPentatonicNotes", () => {
    it("should return major pentatonic for Ionian mode", () => {
      const notes = getPentatonicNotes(TONICS.D, MODES.IONIAN);
      expect(notes).toEqual(["D", "E", "F#", "A", "B"]);
    });

    it("should return minor pentatonic for Dorian mode", () => {
      // D Dorian pentatonic (per requirements: minor pentatonic of root)
      const notes = getPentatonicNotes(TONICS.D, MODES.DORIAN);
      expect(notes).toEqual(["D", "F", "G", "A", "C"]);
    });

    it("should return major pentatonic for Mixolydian mode", () => {
      const notes = getPentatonicNotes(TONICS.G, MODES.MIXOLYDIAN);
      // G Mixolydian -> G Major Pentatonic per updated requirements
      expect(notes).toEqual(["G", "A", "B", "D", "E"]);
    });

    it("should return locrian pentatonic for Locrian mode", () => {
      const notes = getPentatonicNotes(TONICS.C, MODES.LOCRIAN);
      // C Locrian -> C Locrian Pentatonic
      expect(notes).toEqual(["C", "Eb", "F", "Gb", "Bb"]);
    });
  });

  describe("getNoteOctaves", () => {
    it("should return correct octaves for D within violin range G3-A5", () => {
      const octaves = getNoteOctaves(TONICS.D);
      // D4 and D5 should be in range. D3 (midi 50) < G3 (midi 55). D6 > A5.
      expect(octaves).toEqual(["D4", "D5"]);
    });

    it("should return G3, G4, G5 for G note", () => {
      const octaves = getNoteOctaves(TONICS.G);
      expect(octaves).toEqual(["G3", "G4", "G5"]);
    });

    it("should return A3, A4, A5 for A note", () => {
      const octaves = getNoteOctaves(TONICS.A);
      // G3 (55) is the lowest. A3 (57), A4 (69), A5 (81) are all in range.
      expect(octaves).toEqual(["A3", "A4", "A5"]);
    });

    it("should return B3, B4 for B note", () => {
        // B3 (59) and B4 (71) are in range. B5 (83) > A5 (81).
        const octaves = getNoteOctaves(TONICS.B);
        expect(octaves).toEqual(["B3", "B4"]);
    });
  });
});
