import { describe, it, expect, beforeEach } from 'vitest';
import { MeydaDetector } from './meyda-detector';
import { EssentiaDetector } from './essentia-detector';
import { TONICS, MODES } from '../../utils/notes.js';
import { vi } from 'vitest';

// Mock EssentiaWASM
vi.mock('essentia.js/dist/essentia-wasm.es.js', () => {
  return {
    EssentiaWASM: {}
  };
});

describe('Detection Accuracy (Non-C keys)', () => {
  it('MeydaDetector should detect G Major', async () => {
    const detector = new MeydaDetector();
    await detector.init(44100, 4096);

    // G Major: G(7)
    const gMajorChroma = new Array(12).fill(0);
    gMajorChroma[7] = 1.0; // Tonic
    gMajorChroma[2] = 0.8; // Fifth (D)
    gMajorChroma[11] = 0.7; // Major Third (B)
    gMajorChroma[0] = 0.5; // Fourth (C)
    gMajorChroma[9] = 0.4; // Second (A)
    gMajorChroma[4] = 0.4; // Sixth (E)
    gMajorChroma[6] = 0.3; // Seventh (F#)

    detector.chromaHistory.push(gMajorChroma);
    detector.lastSendTime = Date.now() - 600;

    const result = detector.process(new Float32Array(4096));

    expect(result.tonic).toBe(TONICS.G);
    expect(result.mode).toBe(MODES.IONIAN);
  });

  it('MeydaDetector should detect D Dorian', async () => {
    const detector = new MeydaDetector();
    await detector.init(44100, 4096);

    // D Dorian: D(2)
    const dDorianChroma = new Array(12).fill(0);
    dDorianChroma[2] = 1.0; // Tonic (D)
    dDorianChroma[9] = 0.8; // Fifth (A)
    dDorianChroma[5] = 0.7; // Minor Third (F)
    dDorianChroma[7] = 0.6; // Fourth (G)
    dDorianChroma[11] = 0.5; // Sixth (B)
    dDorianChroma[0] = 0.4; // Seventh (C)
    dDorianChroma[4] = 0.3; // Second (E)

    detector.chromaHistory.push(dDorianChroma);
    detector.lastSendTime = Date.now() - 600;

    const result = detector.process(new Float32Array(4096));

    expect(result.tonic).toBe(TONICS.D);
    expect(result.mode).toBe(MODES.DORIAN);
  });

  it('MeydaDetector should detect C Major', async () => {
    const detector = new MeydaDetector();
    await detector.init(44100, 4096);

    // C Major: C(0)
    const cMajorChroma = new Array(12).fill(0);
    cMajorChroma[0] = 1.0; // Tonic
    cMajorChroma[7] = 0.8; // Fifth (G)
    cMajorChroma[4] = 0.7; // Major Third (E)

    detector.chromaHistory.push(cMajorChroma);
    detector.lastSendTime = Date.now() - 600;

    const result = detector.process(new Float32Array(4096));

    expect(result.tonic).toBe(TONICS.C);
    expect(result.mode).toBe(MODES.IONIAN);
  });
});
