import { describe, expect, it } from 'vitest';
import { WebAudioPCPDetector, frequencyToPitchClass, getFloatFrequencyDataFromPcm } from './webaudio-pcp-detector.js';
import { MODES, TONICS } from '../../utils/notes.js';

function renderChord(frequencies, sampleRate, sampleCount) {
  const pcm = new Float32Array(sampleCount);
  for (let sample = 0; sample < sampleCount; sample++) {
    let value = 0;
    for (const frequency of frequencies) {
      value += Math.sin((2 * Math.PI * frequency * sample) / sampleRate);
    }
    pcm[sample] = (value / frequencies.length) * 0.5;
  }
  return pcm;
}

describe('WebAudioPCPDetector', () => {
  it('maps concert-pitch frequencies to C-indexed pitch classes', () => {
    expect(frequencyToPitchClass(261.63)).toBe(0);
    expect(frequencyToPitchClass(293.66)).toBe(2);
    expect(frequencyToPitchClass(440)).toBe(9);
  });

  it('turns PCM FFT magnitudes into a normalized violin-range PCP', async () => {
    const detector = new WebAudioPCPDetector({ fftSize: 8192 });
    await detector.init(44100, 4096);

    const frequencyData = getFloatFrequencyDataFromPcm(renderChord([261.63, 329.63, 392], 44100, 8192), 8192);
    const pcp = detector.frequencyDataToPcp(frequencyData);

    expect(pcp).toHaveLength(12);
    expect(Math.max(...pcp)).toBe(1);
    expect(pcp[0]).toBeGreaterThan(0.5);
    expect(pcp[4]).toBeGreaterThan(0.5);
    expect(pcp[7]).toBeGreaterThan(0.9);
  });

  it('detects a C ionian triad without external DSP dependencies', async () => {
    const detector = new WebAudioPCPDetector({ fftSize: 8192 });
    await detector.init(44100, 4096);
    detector.lastSendTime = Date.now() - 600;

    const detection = detector.process(renderChord([261.63, 329.63, 392], 44100, 8192));

    expect(detection).toMatchObject({ tonic: TONICS.C, mode: MODES.IONIAN });
    expect(detection.chroma).toHaveLength(12);
  });

  it('keeps only the latest FFT frame of PCM history', async () => {
    const detector = new WebAudioPCPDetector({ fftSize: 4096 });
    await detector.init(44100, 4096);

    detector.addToHistory(new Float32Array(2048).fill(0.1));
    detector.addToHistory(new Float32Array(4096).fill(0.2));

    expect(detector.historySampleCount).toBe(4096);
    expect(Array.from(detector.getLatestFrame())).toEqual(Array.from(new Float32Array(4096).fill(0.2)));
  });
});
