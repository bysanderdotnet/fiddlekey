import { describe, it, expect, beforeEach, vi } from 'vitest';
import { TONICS, MODES } from '../../utils/notes.js';

// Mock essentia.js before importing EssentiaDetector
vi.mock('essentia.js/dist/essentia-wasm.es.js', () => {
  return {
    EssentiaWASM: {}
  };
});

vi.mock('essentia.js/dist/essentia.js-core.es.js', () => {
  return {
    default: class MockEssentia {
      constructor() {}
      arrayToVector(arr) { return { delete: () => {} }; }
      Windowing() { return { frame: { delete: () => {} } }; }
      Spectrum() { return { spectrum: { delete: () => {} } }; }
      SpectralPeaks() { return { frequencies: { delete: () => {} }, magnitudes: { delete: () => {} } }; }
      HPCP() { return { hpcp: { delete: () => {} } }; }
      vectorToArray() { return new Array(12).fill(0.1); }
    }
  };
});

import { EssentiaDetector } from './essentia-detector';

describe('EssentiaDetector', () => {
  let detector;

  beforeEach(() => {
    detector = new EssentiaDetector();
  });

  it('should initialize and reset state', async () => {
    await detector.init(44100, 4096);
    expect(detector.sampleRate).toBe(44100);
    expect(detector.maxHistoryLength).toBeGreaterThan(0);
    expect(detector.essentia).toBeDefined();
  });

  it('process() should return null initially if enough time has not passed', async () => {
    await detector.init(44100, 4096);
    detector.lastSendTime = Date.now();
    const pcm = new Float32Array(4096).fill(0.1);
    const result = detector.process(pcm);
    expect(result).toBeNull();
  });

  it('uses Essentia C++ default SpectralPeaks and HPCP parameters for key features', async () => {
    await detector.init(48000, 4096);
    const spectralPeaksSpy = vi.spyOn(detector.essentia, 'SpectralPeaks');
    const hpcpSpy = vi.spyOn(detector.essentia, 'HPCP');

    detector.process(new Float32Array(4096).fill(0.1));

    expect(spectralPeaksSpy).toHaveBeenCalledWith(
      expect.anything(),
      0,
      5000,
      100,
      0,
      'frequency',
      48000
    );
    expect(hpcpSpy).toHaveBeenCalledWith(
      expect.anything(),
      expect.anything(),
      true,
      500,
      0,
      5000.0,
      false,
      40.0,
      false,
      'unitMax',
      440.0,
      48000,
      12,
      'squaredCosine',
      1
    );
  });

  it('normalizes HPCP features and right-rotates them by 9 bins before accumulation', async () => {
    await detector.init(44100, 4096);
    detector.essentia.vectorToArray = vi.fn(() => [1, 2, 3, 4, 5, 6, Number.NaN, -8, 9, 10, 11, 12]);

    detector.process(new Float32Array(4096).fill(0.1));

    expect(detector.hpcpHistory).toHaveLength(1);
    expect(detector.hpcpHistory[0]).toEqual([
      4 / 12,
      5 / 12,
      6 / 12,
      0,
      0,
      9 / 12,
      10 / 12,
      11 / 12,
      1,
      1 / 12,
      2 / 12,
      3 / 12
    ]);
  });

  it('process() should eventually return a DetectionResult after enough data', async () => {
    await detector.init(44100, 4096);
    const pcm = new Float32Array(4096).fill(0);

    // Simulate time passing
    detector.lastSendTime = Date.now() - 600;

    let result = null;
    for (let i = 0; i < 5; i++) {
      result = detector.process(pcm);
      if (result) break;
    }

    expect(result).toBeDefined();
    expect(result).not.toBeNull();
    expect(result).toHaveProperty('tonic');
    expect(result).toHaveProperty('mode');
    expect(result).toHaveProperty('score');
    expect(result).toHaveProperty('chroma');
    expect(result.chroma).toHaveLength(12);
  });

  it('resetHistory() should clear history and smoother', async () => {
    await detector.init(44100, 4096);
    detector.hpcpHistory.push(new Array(12).fill(0));
    detector.smoother.add({ tonic: TONICS.C, mode: MODES.IONIAN });
    detector.lastSendTime = 123456;

    detector.resetHistory();

    expect(detector.hpcpHistory.length).toBe(0);
    expect(detector.smoother.history.length).toBe(0);
    expect(detector.lastSendTime).toBe(0);
  });

  it('after resetHistory(), the detector is still usable', async () => {
    await detector.init(44100, 4096);
    detector.resetHistory();
    detector.lastSendTime = Date.now() - 600;
    const pcm = new Float32Array(4096).fill(0);
    const result = detector.process(pcm);
    expect(result).not.toBeNull();
  });

  it('destroy() should clear resources', async () => {
    await detector.init(44100, 4096);
    detector.destroy();
    expect(detector.essentia).toBeNull();
    expect(detector.hpcpHistory.length).toBe(0);
  });
});
