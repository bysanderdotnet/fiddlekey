import { describe, it, expect } from 'vitest';
import { KeyDetector } from './detector.js';

describe('KeyDetector', () => {
  it('should throw errors when abstract methods are called', async () => {
    const detector = new KeyDetector();

    await expect(detector.init(44100, 2048)).rejects.toThrow('Method "init()" must be implemented.');
    expect(() => detector.process(new Float32Array(2048))).toThrow('Method "process()" must be implemented.');
    expect(() => detector.destroy()).toThrow('Method "destroy()" must be implemented.');
  });
});
