/**
 * Profile-matching utilities for 12-bin chroma key detection.
 *
 * This module builds swappable modal key-profile sets and scores incoming chroma vectors
 * against every tonic/mode rotation. It supports the existing Bourdon Pearson matcher,
 * Temperley-style weighted modal profiles, simple diatonic scale templates, EDMA-style
 * accented modal templates, and Beauguitte ITM-inspired profiles with W=(3,1,2) for
 * tonic, third, and fifth. The scoring layer can use Pearson correlation, cosine
 * similarity, or inverse Euclidean distance while preserving the common traditional-key
 * prior used by the original detector. Final candidates are then refined with mode
 * resolution heuristics that compare characteristic degree energy (natural vs. flat
 * sevenths and sixths) and tonic emphasis inside the candidate scale.
 */
import { MODES, NOTE_NAMES, TONICS } from '../utils/notes.js';

export const PROFILE_SET_IDS = {
  BOURDON: 'bourdon',
  TEMPERLEY: 'temperley',
  DIATONIC: 'diatonic',
  EDMA: 'edma',
  BEAUGUITTE_ITM: 'beauguitteItm'
};

export const PROFILE_METRICS = {
  PEARSON: 'pearson',
  COSINE: 'cosine',
  EUCLIDEAN: 'euclidean'
};

const MODE_INTERVALS = {
  [MODES.IONIAN]: [0, 2, 4, 5, 7, 9, 11],
  [MODES.MIXOLYDIAN]: [0, 2, 4, 5, 7, 9, 10],
  [MODES.DORIAN]: [0, 2, 3, 5, 7, 9, 10],
  [MODES.AEOLIAN]: [0, 2, 3, 5, 7, 8, 10]
};

const CHARACTERISTIC_INTERVALS = {
  [MODES.IONIAN]: [4, 11],
  [MODES.MIXOLYDIAN]: [4, 10],
  [MODES.DORIAN]: [3, 9],
  [MODES.AEOLIAN]: [3, 8]
};

const BOURDON_PROFILES = {
  [MODES.IONIAN]: [8, 0, 2, 0, 2, 3, 0, 7, 0, 1, 0.5, 1.5],
  [MODES.MIXOLYDIAN]: [8, 0, 2, 0, 2, 3, 0, 7, 0, 1, 1.5, 0.5],
  [MODES.DORIAN]: [14, 0, 4, 4, 0, 7, 0, 11, 0.5, 1.5, 7, 0],
  [MODES.AEOLIAN]: [14, 0, 4, 4, 0, 7, 0, 11, 1.5, 0.5, 7, 0]
};

const TEMPERLEY_DEGREE_WEIGHTS = [5, 2, 3.5, 4, 4.5, 3.5, 1.5];
const EDMA_DEGREE_WEIGHTS = [6, 1.75, 3.75, 2.25, 5, 1.5, 3.25];

const MODE_RESOLUTION_DEFAULTS = {
  characteristicBonus: 0.12,
  tonicEmphasisBonus: 0.15,
  nonTonicPenalty: 0.04,
  dominanceThreshold: 0.58,
  epsilon: 1e-9
};

const MODE_RESOLUTION_PAIRS = {
  [MODES.IONIAN]: { contrastingMode: MODES.MIXOLYDIAN, ownInterval: 11, otherInterval: 10 },
  [MODES.MIXOLYDIAN]: { contrastingMode: MODES.IONIAN, ownInterval: 10, otherInterval: 11 },
  [MODES.DORIAN]: { contrastingMode: MODES.AEOLIAN, ownInterval: 9, otherInterval: 8 },
  [MODES.AEOLIAN]: { contrastingMode: MODES.DORIAN, ownInterval: 8, otherInterval: 9 }
};

const COMMON_TRAD_KEYS = [
  { tonic: NOTE_NAMES.indexOf(TONICS.D), mode: MODES.IONIAN },
  { tonic: NOTE_NAMES.indexOf(TONICS.D), mode: MODES.MIXOLYDIAN },
  { tonic: NOTE_NAMES.indexOf(TONICS.G), mode: MODES.IONIAN },
  { tonic: NOTE_NAMES.indexOf(TONICS.G), mode: MODES.MIXOLYDIAN },
  { tonic: NOTE_NAMES.indexOf(TONICS.A), mode: MODES.IONIAN },
  { tonic: NOTE_NAMES.indexOf(TONICS.A), mode: MODES.MIXOLYDIAN },
  { tonic: NOTE_NAMES.indexOf(TONICS.E), mode: MODES.DORIAN },
  { tonic: NOTE_NAMES.indexOf(TONICS.E), mode: MODES.AEOLIAN },
  { tonic: NOTE_NAMES.indexOf(TONICS.A), mode: MODES.DORIAN },
  { tonic: NOTE_NAMES.indexOf(TONICS.A), mode: MODES.AEOLIAN },
  { tonic: NOTE_NAMES.indexOf(TONICS.D), mode: MODES.DORIAN },
  { tonic: NOTE_NAMES.indexOf(TONICS.D), mode: MODES.AEOLIAN },
  { tonic: NOTE_NAMES.indexOf(TONICS.B), mode: MODES.AEOLIAN },
  { tonic: NOTE_NAMES.indexOf(TONICS.C), mode: MODES.IONIAN },
  { tonic: NOTE_NAMES.indexOf(TONICS.G), mode: MODES.AEOLIAN },
  { tonic: NOTE_NAMES.indexOf(TONICS.F), mode: MODES.IONIAN },
];

const PROFILE_BUILDERS = {
  [PROFILE_SET_IDS.BOURDON]: () => BOURDON_PROFILES,
  [PROFILE_SET_IDS.TEMPERLEY]: () => buildDegreeWeightedProfiles(TEMPERLEY_DEGREE_WEIGHTS),
  [PROFILE_SET_IDS.DIATONIC]: () => buildDiatonicProfiles(),
  [PROFILE_SET_IDS.EDMA]: () => buildEdmaProfiles(),
  [PROFILE_SET_IDS.BEAUGUITTE_ITM]: () => buildBeauguitteItmProfiles()
};

const ALL_PROFILE_CACHE = new Map();

export function rotate(arr, n) {
  const len = arr.length;
  const result = new Array(len);
  for (let i = 0; i < len; i++) {
    result[(i + n) % len] = arr[i];
  }
  return result;
}

export function getProfileSet(profileSetId = PROFILE_SET_IDS.BOURDON) {
  const builder = PROFILE_BUILDERS[profileSetId];
  if (!builder) {
    throw new Error(`Unknown profile set: ${profileSetId}`);
  }
  return builder();
}

export function detectKey(chroma, options = {}) {
  const resolvedResults = scoreKeyCandidates(chroma, options);
  if (resolvedResults.length === 0) return null;

  const topMatch = resolvedResults[0];
  const alternate = resolvedResults[1] || topMatch;

  const confidence = topMatch.score > 0
    ? Math.max(0, Math.min(1, (topMatch.score - alternate.score) / topMatch.score * 5))
    : 0;

  return {
    tonic: NOTE_NAMES[topMatch.tonic],
    mode: topMatch.mode,
    score: topMatch.score,
    confidence,
    modeResolution: topMatch.modeResolution,
    alternate: {
      tonic: NOTE_NAMES[alternate.tonic],
      mode: alternate.mode,
      score: alternate.score
    }
  };
}

export function scoreKeyCandidates(chroma, options = {}) {
  const profileSetId = options.profileSetId ?? PROFILE_SET_IDS.BOURDON;
  const metric = options.metric ?? PROFILE_METRICS.PEARSON;
  const commonKeyBoost = options.commonKeyBoost ?? 0.05;

  if (!chroma || chroma.length !== 12) return [];

  const profiles = getAllProfiles(profileSetId);
  const prepared = prepareInput(chroma, metric);
  const enableModeResolution = options.enableModeResolution ?? true;
  const modeResolutionOptions = {
    ...MODE_RESOLUTION_DEFAULTS,
    ...(options.modeResolution ?? {})
  };

  const results = profiles.map(p => {
    const rawScore = scoreProfile(chroma, p.profile, metric, prepared);
    let score = rawScore;

    if (p.isCommon) {
      score += commonKeyBoost;
    }

    return {
      tonic: p.tonic,
      tonicName: NOTE_NAMES[p.tonic],
      mode: p.mode,
      rawScore,
      score
    };
  });

  results.sort((a, b) => b.score - a.score);

  if (results.length === 0) return [];

  return enableModeResolution
    ? applyModeResolutionHeuristics(chroma, results, modeResolutionOptions)
    : results;
}

function applyModeResolutionHeuristics(chroma, results, options) {
  const adjusted = results.map(result => {
    const modeResolution = getModeResolutionAdjustment(chroma, result, options);
    return {
      ...result,
      score: result.score + modeResolution.adjustment,
      modeResolution
    };
  });

  adjusted.sort((a, b) => b.score - a.score);
  return adjusted;
}

function getModeResolutionAdjustment(chroma, result, options) {
  const characteristic = getCharacteristicDegreeAdjustment(chroma, result, options);
  const tonicEmphasis = getTonicEmphasisAdjustment(chroma, result, options);

  return {
    adjustment: characteristic.adjustment + tonicEmphasis.adjustment,
    characteristic,
    tonicEmphasis
  };
}

function getCharacteristicDegreeAdjustment(chroma, result, options) {
  const pair = MODE_RESOLUTION_PAIRS[result.mode];
  if (!pair) {
    return { adjustment: 0, ratio: 0, comparedWith: null };
  }

  const ownEnergy = getChromaAtInterval(chroma, result.tonic, pair.ownInterval);
  const otherEnergy = getChromaAtInterval(chroma, result.tonic, pair.otherInterval);
  const total = ownEnergy + otherEnergy + options.epsilon;
  const ratio = ownEnergy / total;
  const adjustment = ratio >= options.dominanceThreshold ? options.characteristicBonus * ratio : 0;

  return {
    adjustment,
    ratio,
    ownInterval: pair.ownInterval,
    otherInterval: pair.otherInterval,
    comparedWith: pair.contrastingMode
  };
}

function getTonicEmphasisAdjustment(chroma, result, options) {
  const intervals = MODE_INTERVALS[result.mode];
  if (!intervals) return { adjustment: 0, tonicEnergy: 0, strongestScaleEnergy: 0 };

  const tonicEnergy = getChromaAtInterval(chroma, result.tonic, 0);
  const strongestScaleEnergy = Math.max(...intervals.map(interval => getChromaAtInterval(chroma, result.tonic, interval)));

  if (strongestScaleEnergy <= options.epsilon) {
    return { adjustment: 0, tonicEnergy, strongestScaleEnergy };
  }

  const tonicRatio = tonicEnergy / (strongestScaleEnergy + options.epsilon);
  const isStrongestScaleDegree = tonicEnergy + options.epsilon >= strongestScaleEnergy;

  return {
    adjustment: isStrongestScaleDegree
      ? options.tonicEmphasisBonus * tonicRatio
      : -options.nonTonicPenalty * (1 - tonicRatio),
    tonicEnergy,
    strongestScaleEnergy,
    tonicRatio,
    isStrongestScaleDegree
  };
}

function getChromaAtInterval(chroma, tonic, interval) {
  return Math.max(0, chroma[(tonic + interval) % 12] ?? 0);
}

function getAllProfiles(profileSetId) {
  if (ALL_PROFILE_CACHE.has(profileSetId)) {
    return ALL_PROFILE_CACHE.get(profileSetId);
  }

  const baseProfiles = getProfileSet(profileSetId);
  const commonKeysSet = new Set(COMMON_TRAD_KEYS.map(k => `${k.tonic}-${k.mode}`));
  const profiles = [];

  for (let tonic = 0; tonic < 12; tonic++) {
    for (const [mode, baseProfile] of Object.entries(baseProfiles)) {
      profiles.push({
        tonic,
        mode,
        profile: rotate(baseProfile, tonic),
        isCommon: commonKeysSet.has(`${tonic}-${mode}`)
      });
    }
  }

  ALL_PROFILE_CACHE.set(profileSetId, profiles);
  return profiles;
}

function prepareInput(chroma, metric) {
  if (metric !== PROFILE_METRICS.PEARSON) return null;

  const n = chroma.length;
  const mean = chroma.reduce((a, b) => a + b, 0) / n;
  let variance = 0;
  for (let i = 0; i < n; i++) {
    variance += Math.pow(chroma[i] - mean, 2);
  }
  return { mean, variance };
}

function scoreProfile(chroma, profile, metric, prepared) {
  switch (metric) {
    case PROFILE_METRICS.COSINE:
      return cosineSimilarity(chroma, profile);
    case PROFILE_METRICS.EUCLIDEAN:
      return inverseEuclideanSimilarity(chroma, profile);
    case PROFILE_METRICS.PEARSON:
      return pearsonCorrelation(chroma, profile, prepared.mean, prepared.variance);
    default:
      throw new Error(`Unknown profile metric: ${metric}`);
  }
}

function pearsonCorrelation(x, y, muX, denX) {
  const n = x.length;
  const muY = y.reduce((a, b) => a + b, 0) / n;

  let num = 0;
  let denY = 0;

  for (let i = 0; i < n; i++) {
    const diffX = x[i] - muX;
    const diffY = y[i] - muY;
    num += diffX * diffY;
    denY += diffY * diffY;
  }

  const denominator = Math.sqrt(denX * denY);
  if (denominator === 0) return 0;
  return num / denominator;
}

function cosineSimilarity(x, y) {
  let dot = 0;
  let magX = 0;
  let magY = 0;

  for (let i = 0; i < x.length; i++) {
    dot += x[i] * y[i];
    magX += x[i] * x[i];
    magY += y[i] * y[i];
  }

  const denominator = Math.sqrt(magX) * Math.sqrt(magY);
  if (denominator === 0) return 0;
  return dot / denominator;
}

function inverseEuclideanSimilarity(x, y) {
  const normalizedX = normalizeL1(x);
  const normalizedY = normalizeL1(y);
  let squaredDistance = 0;

  for (let i = 0; i < normalizedX.length; i++) {
    squaredDistance += Math.pow(normalizedX[i] - normalizedY[i], 2);
  }

  return 1 / (1 + Math.sqrt(squaredDistance));
}

function normalizeL1(values) {
  const sum = values.reduce((total, value) => total + Math.max(0, value), 0);
  if (sum <= 0) return values.map(() => 0);
  return values.map(value => Math.max(0, value) / sum);
}

function buildDegreeWeightedProfiles(degreeWeights) {
  return Object.fromEntries(Object.entries(MODE_INTERVALS).map(([mode, intervals]) => {
    const profile = new Array(12).fill(0);
    intervals.forEach((interval, degreeIndex) => {
      profile[interval] = degreeWeights[degreeIndex];
    });
    return [mode, profile];
  }));
}

function buildDiatonicProfiles() {
  return Object.fromEntries(Object.entries(MODE_INTERVALS).map(([mode, intervals]) => {
    const profile = new Array(12).fill(0);
    intervals.forEach(interval => {
      profile[interval] = 1;
    });
    profile[0] = 2;
    profile[7] = 1.5;
    return [mode, profile];
  }));
}

function buildEdmaProfiles() {
  const profiles = buildDegreeWeightedProfiles(EDMA_DEGREE_WEIGHTS);

  for (const [mode, intervals] of Object.entries(CHARACTERISTIC_INTERVALS)) {
    for (const interval of intervals) {
      profiles[mode][interval] += 1;
    }
  }

  return profiles;
}

function buildBeauguitteItmProfiles() {
  return Object.fromEntries(Object.entries(MODE_INTERVALS).map(([mode, intervals]) => {
    const profile = new Array(12).fill(0);
    intervals.forEach(interval => {
      profile[interval] = 0.5;
    });
    profile[0] = 3;
    profile[7] = 2;
    profile[getThirdInterval(mode)] = 1;
    return [mode, profile];
  }));
}

function getThirdInterval(mode) {
  return mode === MODES.DORIAN || mode === MODES.AEOLIAN ? 3 : 4;
}
