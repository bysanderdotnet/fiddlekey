import { describe, it, expect, vi } from 'vitest';
import { createDetector, getDetectorIds, getDetectorOptions } from './factory.js';

// Mock dependencies
vi.mock('./specifics/essentia-detector.js', () => ({
  EssentiaDetector: class MockEssentiaDetector {},
  EssentiaTemperleyDetector: class MockEssentiaTemperleyDetector {},
  EssentiaDiatonicDetector: class MockEssentiaDiatonicDetector {},
  EssentiaEdmaDetector: class MockEssentiaEdmaDetector {},
  EssentiaBeauguitteItmDetector: class MockEssentiaBeauguitteItmDetector {},
  EssentiaBeauguitteItmEuclideanDetector: class MockEssentiaBeauguitteItmEuclideanDetector {}
}));

vi.mock('./specifics/meyda-detector.js', () => ({
  MeydaDetector: class MockMeydaDetector {}
}));

vi.mock('./specifics/essentia-key-extractor-detector.js', () => ({
  KeyEssentiaKeyExtractorDetector: class MockKeyEssentiaKeyExtractorDetector {}
}));

vi.mock('./specifics/essentia-nnls-detector.js', () => ({
  KeyEssentiaNNLSDetector: class MockKeyEssentiaNNLSDetector {}
}));

vi.mock('./specifics/webaudio-pcp-detector.js', () => ({
  WebAudioPCPDetector: class MockWebAudioPCPDetector {}
}));

vi.mock('./specifics/onnx-cnn-detector.js', () => ({
  OnnxCnnDetector: class MockOnnxCnnDetector {}
}));

vi.mock('./specifics/ml-pitch-histogram-detector.js', () => ({
  MLPitchHistogramDetector: class MockMLPitchHistogramDetector {}
}));

vi.mock('./specifics/ensemble-detector.js', () => ({
  EnsembleDetector: class MockEnsembleDetector {}
}));

vi.mock('./specifics/hf-key-class-detector.js', () => ({
  HFKeyClassDetector: class MockHFKeyClassDetector {},
  HFKeyClassNonQuantizedDetector: class MockHFKeyClassNonQuantizedDetector {}
}));

const EXPECTED_OPTIONS = [
  { id: 'essentia', label: 'Essentia.js HPCP' },
  { id: 'essentiaTemperley', label: 'Essentia.js HPCP (Temperley profiles)' },
  { id: 'essentiaDiatonic', label: 'Essentia.js HPCP (Diatonic profiles)' },
  { id: 'essentiaEdma', label: 'Essentia.js HPCP (EDMA profiles)' },
  { id: 'essentiaBeauguitteItm', label: 'Essentia.js HPCP (Beauguitte ITM cosine)' },
  { id: 'essentiaBeauguitteItmEuclidean', label: 'Essentia.js HPCP (Beauguitte ITM Euclidean)' },
  { id: 'essentiaKeyExtractor', label: 'Essentia.js KeyExtractor' },
  { id: 'essentiaNnls', label: 'Essentia.js NNLS chroma' },
  { id: 'webaudioPcp', label: 'Web Audio PCP' },
  { id: 'meyda', label: 'Meyda chroma' },
  { id: 'onnxCnn', label: 'ONNX CNN key classifier' },
  { id: 'mlPitchHistogram', label: 'ML pitch-tracking histogram' },
  { id: 'ensemble', label: 'Ensemble (Essentia + Meyda + Web Audio)' },
  { id: 'hfKeyClass', label: 'HF Key Class CNN (jcarbonnell)' },
  { id: 'hfKeyClassNonQuantized', label: 'HF Key Class CNN nonquantized (jcarbonnell)' }
];

describe('Detector Factory', () => {
  it('should create an EssentiaDetector when id is "essentia"', async () => {
    const { EssentiaDetector } = await import('./specifics/essentia-detector.js');
    const detector = await createDetector('essentia');
    expect(detector).toBeInstanceOf(EssentiaDetector);
  });

  it('should create Essentia profile-variant detectors', async () => {
    const specifics = await import('./specifics/essentia-detector.js');

    await expect(createDetector('essentiaTemperley')).resolves.toBeInstanceOf(specifics.EssentiaTemperleyDetector);
    await expect(createDetector('essentiaDiatonic')).resolves.toBeInstanceOf(specifics.EssentiaDiatonicDetector);
    await expect(createDetector('essentiaEdma')).resolves.toBeInstanceOf(specifics.EssentiaEdmaDetector);
    await expect(createDetector('essentiaBeauguitteItm')).resolves.toBeInstanceOf(specifics.EssentiaBeauguitteItmDetector);
    await expect(createDetector('essentiaBeauguitteItmEuclidean')).resolves.toBeInstanceOf(specifics.EssentiaBeauguitteItmEuclideanDetector);
  });

  it('should create a MeydaDetector when id is "meyda"', async () => {
    const { MeydaDetector } = await import('./specifics/meyda-detector.js');
    const detector = await createDetector('meyda');
    expect(detector).toBeInstanceOf(MeydaDetector);
  });

  it('should create a KeyEssentiaKeyExtractorDetector when id is "essentiaKeyExtractor"', async () => {
    const { KeyEssentiaKeyExtractorDetector } = await import('./specifics/essentia-key-extractor-detector.js');
    const detector = await createDetector('essentiaKeyExtractor');
    expect(detector).toBeInstanceOf(KeyEssentiaKeyExtractorDetector);
  });

  it('should create a KeyEssentiaNNLSDetector when id is "essentiaNnls"', async () => {
    const { KeyEssentiaNNLSDetector } = await import('./specifics/essentia-nnls-detector.js');
    const detector = await createDetector('essentiaNnls');
    expect(detector).toBeInstanceOf(KeyEssentiaNNLSDetector);
  });

  it('should create a WebAudioPCPDetector when id is "webaudioPcp"', async () => {
    const { WebAudioPCPDetector } = await import('./specifics/webaudio-pcp-detector.js');
    const detector = await createDetector('webaudioPcp');
    expect(detector).toBeInstanceOf(WebAudioPCPDetector);
  });

  it('should create an OnnxCnnDetector when id is "onnxCnn"', async () => {
    const { OnnxCnnDetector } = await import('./specifics/onnx-cnn-detector.js');
    const detector = await createDetector('onnxCnn');
    expect(detector).toBeInstanceOf(OnnxCnnDetector);
  });

  it('should create an MLPitchHistogramDetector when id is "mlPitchHistogram"', async () => {
    const { MLPitchHistogramDetector } = await import('./specifics/ml-pitch-histogram-detector.js');
    const detector = await createDetector('mlPitchHistogram');
    expect(detector).toBeInstanceOf(MLPitchHistogramDetector);
  });

  it('should create an EnsembleDetector when id is "ensemble"', async () => {
    const { EnsembleDetector } = await import('./specifics/ensemble-detector.js');
    const detector = await createDetector('ensemble');
    expect(detector).toBeInstanceOf(EnsembleDetector);
  });

  it('should create an HFKeyClassDetector when id is "hfKeyClass"', async () => {
    const { HFKeyClassDetector } = await import('./specifics/hf-key-class-detector.js');
    const detector = await createDetector('hfKeyClass');
    expect(detector).toBeInstanceOf(HFKeyClassDetector);
  });

  it('should create an HFKeyClassNonQuantizedDetector when id is "hfKeyClassNonQuantized"', async () => {
    const { HFKeyClassNonQuantizedDetector } = await import('./specifics/hf-key-class-detector.js');
    const detector = await createDetector('hfKeyClassNonQuantized');
    expect(detector).toBeInstanceOf(HFKeyClassNonQuantizedDetector);
  });

  it('should list every available detector for UI and benchmarks', () => {
    expect(getDetectorIds()).toEqual(EXPECTED_OPTIONS.map(({ id }) => id));
    expect(getDetectorOptions()).toEqual(EXPECTED_OPTIONS);
  });

  it('should throw an error for unknown detector IDs', async () => {
    await expect(createDetector('unknown')).rejects.toThrow('Unknown detector ID: unknown');
  });
});
