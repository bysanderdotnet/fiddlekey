/**
 * src/detection/factory.js
 */

export const DETECTORS = {
  essentia: {
    id: 'essentia',
    label: 'Essentia.js HPCP',
    loadDetectorClass: async () => (await import('./specifics/essentia-detector.js')).EssentiaDetector
  },
  essentiaTemperley: {
    id: 'essentiaTemperley',
    label: 'Essentia.js HPCP (Temperley profiles)',
    loadDetectorClass: async () => (await import('./specifics/essentia-detector.js')).EssentiaTemperleyDetector
  },
  essentiaDiatonic: {
    id: 'essentiaDiatonic',
    label: 'Essentia.js HPCP (Diatonic profiles)',
    loadDetectorClass: async () => (await import('./specifics/essentia-detector.js')).EssentiaDiatonicDetector
  },
  essentiaEdma: {
    id: 'essentiaEdma',
    label: 'Essentia.js HPCP (EDMA profiles)',
    loadDetectorClass: async () => (await import('./specifics/essentia-detector.js')).EssentiaEdmaDetector
  },
  essentiaBeauguitteItm: {
    id: 'essentiaBeauguitteItm',
    label: 'Essentia.js HPCP (Beauguitte ITM cosine)',
    loadDetectorClass: async () => (await import('./specifics/essentia-detector.js')).EssentiaBeauguitteItmDetector
  },
  essentiaBeauguitteItmEuclidean: {
    id: 'essentiaBeauguitteItmEuclidean',
    label: 'Essentia.js HPCP (Beauguitte ITM Euclidean)',
    loadDetectorClass: async () => (await import('./specifics/essentia-detector.js')).EssentiaBeauguitteItmEuclideanDetector
  },
  essentiaKeyExtractor: {
    id: 'essentiaKeyExtractor',
    label: 'Essentia.js KeyExtractor',
    loadDetectorClass: async () => (await import('./specifics/essentia-key-extractor-detector.js')).KeyEssentiaKeyExtractorDetector
  },
  essentiaNnls: {
    id: 'essentiaNnls',
    label: 'Essentia.js NNLS chroma',
    loadDetectorClass: async () => (await import('./specifics/essentia-nnls-detector.js')).KeyEssentiaNNLSDetector
  },
  webaudioPcp: {
    id: 'webaudioPcp',
    label: 'Web Audio PCP',
    loadDetectorClass: async () => (await import('./specifics/webaudio-pcp-detector.js')).WebAudioPCPDetector
  },
  meyda: {
    id: 'meyda',
    label: 'Meyda chroma',
    loadDetectorClass: async () => (await import('./specifics/meyda-detector.js')).MeydaDetector
  },
  onnxCnn: {
    id: 'onnxCnn',
    label: 'ONNX CNN key classifier',
    loadDetectorClass: async () => (await import('./specifics/onnx-cnn-detector.js')).OnnxCnnDetector
  },
  mlPitchHistogram: {
    id: 'mlPitchHistogram',
    label: 'ML pitch-tracking histogram',
    loadDetectorClass: async () => (await import('./specifics/ml-pitch-histogram-detector.js')).MLPitchHistogramDetector
  },
  ensemble: {
    id: 'ensemble',
    label: 'Ensemble (Essentia + Meyda + Web Audio)',
    loadDetectorClass: async () => (await import('./specifics/ensemble-detector.js')).EnsembleDetector
  },
  hfKeyClass: {
    id: 'hfKeyClass',
    label: 'HF Key Class CNN (jcarbonnell)',
    loadDetectorClass: async () => (await import('./specifics/hf-key-class-detector.js')).HFKeyClassDetector
  },
  hfKeyClassNonQuantized: {
    id: 'hfKeyClassNonQuantized',
    label: 'HF Key Class CNN nonquantized (jcarbonnell)',
    loadDetectorClass: async () => (await import('./specifics/hf-key-class-detector.js')).HFKeyClassNonQuantizedDetector
  }
};

export const DEFAULT_DETECTOR_ID = 'essentia';

export function getDetectorOptions() {
  return Object.values(DETECTORS).map(({ id, label }) => ({ id, label }));
}

export function getDetectorIds() {
  return getDetectorOptions().map(({ id }) => id);
}

/**
 * Creates and returns an uninitialized KeyDetector instance by ID.
 * @param {string} id
 * @returns {Promise<KeyDetector>}
 */
export async function createDetector(id = DEFAULT_DETECTOR_ID) {
  const detector = DETECTORS[id];
  if (!detector) {
    throw new Error(`Unknown detector ID: ${id}`);
  }

  const DetectorClass = await detector.loadDetectorClass();
  return new DetectorClass();
}
