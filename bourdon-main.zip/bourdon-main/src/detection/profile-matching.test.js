import { describe, expect, it } from 'vitest';
import { detectKey, getProfileSet, PROFILE_METRICS, PROFILE_SET_IDS } from './profile-matching.js';
import { MODES, TONICS } from '../utils/notes.js';

function chromaFromIntervals(root, intervals) {
  const chroma = new Array(12).fill(0);
  for (const [interval, weight] of intervals) {
    chroma[(root + interval) % 12] = weight;
  }
  return chroma;
}

describe('profile matching', () => {
  it('exposes all profile sets required by profile-variant detectors', () => {
    for (const profileSetId of Object.values(PROFILE_SET_IDS)) {
      const profileSet = getProfileSet(profileSetId);
      expect(Object.keys(profileSet).sort()).toEqual([
        MODES.AEOLIAN,
        MODES.DORIAN,
        MODES.IONIAN,
        MODES.MIXOLYDIAN
      ].sort());
      for (const profile of Object.values(profileSet)) {
        expect(profile).toHaveLength(12);
        expect(profile.some(value => value > 0)).toBe(true);
      }
    }
  });

  it('uses Beauguitte ITM W=(3,1,2) accents for tonic, modal third, and fifth', () => {
    const profiles = getProfileSet(PROFILE_SET_IDS.BEAUGUITTE_ITM);

    expect(profiles[MODES.IONIAN][0]).toBe(3);
    expect(profiles[MODES.IONIAN][4]).toBe(1);
    expect(profiles[MODES.IONIAN][7]).toBe(2);

    expect(profiles[MODES.DORIAN][0]).toBe(3);
    expect(profiles[MODES.DORIAN][3]).toBe(1);
    expect(profiles[MODES.DORIAN][7]).toBe(2);
  });

  it('detects a profile-matched G major chroma with cosine and Euclidean metrics', () => {
    const gMajorChroma = chromaFromIntervals(7, [[0, 3], [4, 1], [7, 2], [2, 0.5], [5, 0.5], [9, 0.5], [11, 0.5]]);

    const cosine = detectKey(gMajorChroma, {
      profileSetId: PROFILE_SET_IDS.BEAUGUITTE_ITM,
      metric: PROFILE_METRICS.COSINE
    });
    const euclidean = detectKey(gMajorChroma, {
      profileSetId: PROFILE_SET_IDS.BEAUGUITTE_ITM,
      metric: PROFILE_METRICS.EUCLIDEAN
    });

    expect(cosine.tonic).toBe(TONICS.G);
    expect(cosine.mode).toBe(MODES.IONIAN);
    expect(euclidean.tonic).toBe(TONICS.G);
    expect(euclidean.mode).toBe(MODES.IONIAN);
  });

  it('uses characteristic sevenths to resolve Ionian and Mixolydian with the same tonic', () => {
    const cIonian = chromaFromIntervals(0, [[0, 4], [2, 1], [4, 2], [5, 1], [7, 3], [9, 1], [11, 3], [10, 0.1]]);
    const cMixolydian = chromaFromIntervals(0, [[0, 4], [2, 1], [4, 2], [5, 1], [7, 3], [9, 1], [10, 3], [11, 0.1]]);

    const ionian = detectKey(cIonian, { commonKeyBoost: 0 });
    const mixolydian = detectKey(cMixolydian, { commonKeyBoost: 0 });

    expect(ionian.tonic).toBe(TONICS.C);
    expect(ionian.mode).toBe(MODES.IONIAN);
    expect(ionian.modeResolution.characteristic.ownInterval).toBe(11);
    expect(ionian.modeResolution.characteristic.ratio).toBeGreaterThan(0.9);

    expect(mixolydian.tonic).toBe(TONICS.C);
    expect(mixolydian.mode).toBe(MODES.MIXOLYDIAN);
    expect(mixolydian.modeResolution.characteristic.ownInterval).toBe(10);
    expect(mixolydian.modeResolution.characteristic.ratio).toBeGreaterThan(0.9);
  });

  it('uses characteristic sixths to resolve Dorian and Aeolian with the same tonic', () => {
    const dDorian = chromaFromIntervals(2, [[0, 4], [2, 1], [3, 2], [5, 1], [7, 3], [9, 3], [10, 2], [8, 0.1]]);
    const dAeolian = chromaFromIntervals(2, [[0, 4], [2, 1], [3, 2], [5, 1], [7, 3], [8, 3], [10, 2], [9, 0.1]]);

    const dorian = detectKey(dDorian, { commonKeyBoost: 0 });
    const aeolian = detectKey(dAeolian, { commonKeyBoost: 0 });

    expect(dorian.tonic).toBe(TONICS.D);
    expect(dorian.mode).toBe(MODES.DORIAN);
    expect(dorian.modeResolution.characteristic.ownInterval).toBe(9);
    expect(dorian.modeResolution.characteristic.ratio).toBeGreaterThan(0.9);

    expect(aeolian.tonic).toBe(TONICS.D);
    expect(aeolian.mode).toBe(MODES.AEOLIAN);
    expect(aeolian.modeResolution.characteristic.ownInterval).toBe(8);
    expect(aeolian.modeResolution.characteristic.ratio).toBeGreaterThan(0.9);
  });

  it('uses tonic emphasis to prefer the mode root within a shared key signature', () => {
    const gMixolydianOverCMajorPitchSet = chromaFromIntervals(7, [[0, 5], [2, 1], [4, 2], [5, 1], [7, 3], [9, 1], [10, 3]]);

    const result = detectKey(gMixolydianOverCMajorPitchSet, { commonKeyBoost: 0 });

    expect(result.tonic).toBe(TONICS.G);
    expect(result.mode).toBe(MODES.MIXOLYDIAN);
    expect(result.modeResolution.tonicEmphasis.isStrongestScaleDegree).toBe(true);
  });

});
