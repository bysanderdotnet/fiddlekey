import { test, expect } from '@playwright/test';

test('initial UI state', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('h1')).toContainText('Bourdon');
  await expect(page.locator('#startButton')).toContainText('Detect modality');
  await expect(page.locator('.key-badge')).toContainText('---');
  await expect(page.locator('#new-song-button')).toHaveCount(0);
  await expect(page.locator('#autoDetectionToggle')).toHaveCount(0);
});

test('clicking detect modality enters analyzing state', async ({ page }) => {
  await page.goto('/');

  // Close onboarding first
  await page.click('#closeOnboarding');

  const detectButton = page.locator('#startButton');

  await detectButton.click();
  await expect(detectButton).toContainText(/Initializing|Analyzing/);
  await expect(detectButton).toBeDisabled();
  await expect(page.locator('#key-display')).toHaveClass(/is-listening/);
  await expect(page.locator('.key-badge')).toContainText('Analyzing...');
});

test('error message display when permission is denied', async ({ page }) => {
  // Mocking microphone access failure BEFORE going to the page
  await page.addInitScript(() => {
    Object.defineProperty(navigator.mediaDevices, 'getUserMedia', {
      value: () => Promise.reject(new Error('Permission denied')),
      configurable: true
    });
  });

  await page.goto('/');

  // Close onboarding first
  await page.click('#closeOnboarding');

  const detectButton = page.locator('#startButton');
  await detectButton.click();

  await expect(page.locator('#error-message')).toContainText('Error: Microphone access is required');
  await expect(detectButton).toContainText('Detect modality');
  await expect(detectButton).toBeEnabled();
});
