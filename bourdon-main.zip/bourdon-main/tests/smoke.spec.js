import { test, expect } from '@playwright/test';

test('app starts without console errors or uncaught exceptions', async ({ page }) => {
  const consoleErrors = [];
  const pageErrors = [];

  // Collect console.error() calls from the page
  page.on('console', (msg) => {
    if (msg.type() === 'error') {
      consoleErrors.push(msg.text());
    }
  });

  // Collect uncaught JS exceptions
  page.on('pageerror', (err) => {
    pageErrors.push(`${err.name}: ${err.message}`);
  });

  // 1. Load the page
  await page.goto('/');

  // 2. Dismiss onboarding popup
  await page.click('#closeOnboarding');
  await expect(page.locator('#onboarding')).toBeHidden();

  // 3. Click "Detect modality" to trigger getUserMedia + AudioWorklet
  const detectButton = page.locator('#startButton');
  await detectButton.click();

  // 4. Wait for the button to transition to an analyzing state
  //    (confirms the audio pipeline started successfully)
  await expect(detectButton).toHaveText('Analyzing...', { timeout: 15_000 });

  // 5. Allow a few seconds for the worker and worklet to initialize
  //    and for any async errors to surface
  await page.waitForTimeout(4_000);

  // 6. Assert no errors
  expect(
    pageErrors,
    `Uncaught exceptions: ${pageErrors.join('\n')}`
  ).toHaveLength(0);

  expect(
    consoleErrors.filter(msg =>
      // Filter known-harmless Chromium/Essentia warnings if needed
      !msg.includes('AudioContext was not allowed to start') &&
      !msg.includes('does not provide an export named \'EssentiaWASM\'')
    ),
    `console.error calls: ${consoleErrors.join('\n')}`
  ).toHaveLength(0);
});
