import { test, expect } from '@playwright/test';

test('onboarding overlay is shown on first visit and hidden after clicking "Got it!"', async ({ page }) => {
  await page.goto('/');

  const onboarding = page.locator('#onboarding');
  await expect(onboarding).toBeVisible();

  await page.click('#closeOnboarding');
  await expect(onboarding).toBeHidden();

  // Reload to check if it stays hidden
  await page.reload();
  await expect(onboarding).toBeHidden();
});

test('install button becomes visible on beforeinstallprompt event', async ({ page }) => {
  await page.goto('/');
  await page.waitForLoadState('networkidle');

  const installButton = page.locator('#installButton');
  await expect(installButton).toBeHidden();

  // Dispatch the beforeinstallprompt event
  await page.evaluate(() => {
    const event = new Event('beforeinstallprompt');
    // Mock the prompt() method and userChoice property as they are used in the click handler
    event.prompt = () => {};
    event.userChoice = Promise.resolve({ outcome: 'accepted' });
    window.dispatchEvent(event);
  });

  await expect(installButton).toBeVisible();
});
