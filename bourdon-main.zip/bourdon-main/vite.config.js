import { readFileSync, existsSync, unlinkSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
import { defineConfig } from 'vite';
import { nodePolyfills } from 'vite-plugin-node-polyfills';
import { VitePWA } from 'vite-plugin-pwa';

const require = createRequire(import.meta.url);
const __dirname = dirname(fileURLToPath(import.meta.url));

const R2_BASE_URL = 'https://r2-bourdon.bysander.net';
const r2Assets = JSON.parse(readFileSync(new URL('./r2-assets.json', import.meta.url), 'utf-8'));

function copyEssentiaWasm() {
  return {
    name: 'copy-essentia-wasm',
    generateBundle() {
      this.emitFile({
        type: 'asset',
        fileName: 'assets/essentia-wasm.web.wasm',
        source: readFileSync(require.resolve('essentia.js/dist/essentia-wasm.web.wasm')),
      });
    },
  };
}

function removeR2Assets() {
  return {
    name: 'remove-r2-assets',
    apply: 'build',
    closeBundle() {
      for (const { dest } of r2Assets) {
        const filePath = resolve(__dirname, 'dist', dest);
        if (existsSync(filePath)) unlinkSync(filePath);
      }
    },
  };
}

export default defineConfig(() => ({
  resolve: {
    conditions: ['onnxruntime-web-use-extern-wasm', 'module', 'browser', 'development|production'],
  },
  optimizeDeps: { exclude: ['essentia.js', 'onnxruntime-web'] },
  define: {
    __MODEL_BASE_URL__: JSON.stringify(R2_BASE_URL),
  },
  plugins: [
    nodePolyfills(),
    copyEssentiaWasm(),
    removeR2Assets(),
    VitePWA({
      registerType: 'autoUpdate',
      manifest: {
        name: 'Bourdon',
        short_name: 'Bourdon',
        description: 'A real-time jam session companion for beginner folk violin players.',
        start_url: '/',
        display: 'standalone',
        theme_color: '#000000',
        icons: [
          {
            src: '/favicon.svg',
            sizes: '192x192',
            type: 'image/svg+xml'
          },
          {
            src: '/android-chrome-192x192.png',
            sizes: '192x192',
            type: 'image/png'
          },
          {
            src: '/android-chrome-512x512.png',
            sizes: '512x512',
            type: 'image/png'
          },
          {
            src: '/apple-touch-icon.png',
            sizes: '180x180',
            type: 'image/png'
          }
        ]
      },
      workbox: {
        globPatterns: ['**/*.{js,css,html,ico,png,svg,wasm}'],
        maximumFileSizeToCacheInBytes: 16 * 1024 * 1024 // 16MB to accommodate Essentia and ONNX WASM runtimes
      }
    })
  ]
}));
